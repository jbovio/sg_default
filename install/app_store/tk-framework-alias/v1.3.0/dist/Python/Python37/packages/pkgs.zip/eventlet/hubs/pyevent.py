raise ImportError(
    "Eventlet pyevent hub was removed because it was not maintained."
    " Try version 0.22.1 or older. Sorry for the inconvenience."
)
